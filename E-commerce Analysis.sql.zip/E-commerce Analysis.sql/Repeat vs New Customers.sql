WITH first_purchase AS (
    SELECT customer_id, MIN(order_date) AS first_order
    FROM model-ruler-427606-r7.Ecommerce.orders
    GROUP BY customer_id
)
SELECT COUNT(DISTINCT CASE WHEN orders.order_date = first_purchase.first_order THEN orders.customer_id END) AS new_customers,
       COUNT(DISTINCT CASE WHEN orders.order_date > first_purchase.first_order THEN orders.customer_id END) AS repeat_customers
FROM model-ruler-427606-r7.Ecommerce.orders
JOIN first_purchase ON orders.customer_id = first_purchase.customer_id;
