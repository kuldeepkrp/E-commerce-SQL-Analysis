SELECT customers.customer_id, customers.name, SUM(orders.quantity * products.price) AS total_spent
FROM model-ruler-427606-r7.Ecommerce.orders

JOIN model-ruler-427606-r7.Ecommerce.customers
ON orders.customer_id = customers.customer_id
JOIN model-ruler-427606-r7.Ecommerce.products ON orders.product_id = products.product_id
GROUP BY customers.customer_id, customers.name
ORDER BY total_spent DESC
LIMIT 5;