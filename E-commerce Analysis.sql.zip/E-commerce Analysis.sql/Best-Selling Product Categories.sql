SELECT products.category, SUM(orders.quantity) AS total_sold
FROM model-ruler-427606-r7.Ecommerce.orders
JOIN model-ruler-427606-r7.Ecommerce.products ON orders.product_id = products.product_id
GROUP BY products.category
ORDER BY total_sold DESC;
