SELECT AVG(order_value) AS avg_order_value
FROM (
    SELECT orders.order_id, SUM(orders.quantity * products.price) AS order_value
    FROM model-ruler-427606-r7.Ecommerce.orders
    JOIN model-ruler-427606-r7.Ecommerce.products ON orders.product_id = products.product_id
    GROUP BY orders.order_id
);
