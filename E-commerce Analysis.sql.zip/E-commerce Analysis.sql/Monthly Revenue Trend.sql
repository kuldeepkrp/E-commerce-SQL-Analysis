SELECT FORMAT_DATE('%Y-%m', orders.order_date) AS month,
       SUM(orders.quantity * products.price) AS revenue
FROM model-ruler-427606-r7.Ecommerce.orders

JOIN model-ruler-427606-r7.Ecommerce.products ON orders.product_id = products.product_id
GROUP BY month
ORDER BY month;
